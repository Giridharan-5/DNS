import subprocess

ZONE_FILE = "/etc/bind/db.mfg-itis.tcs"


def update_dns(domain, ip):
    record = domain.split(".")[0]

    with open(ZONE_FILE, "a") as zone:
        zone.write(f"\n{record}\tIN\tA\t{ip}\n")

    subprocess.run(["rndc", "reload"], check=True)

    return f"Update: DNS record {domain} → {ip} added and BIND reloaded"

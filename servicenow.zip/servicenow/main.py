from agent_servicenow import fetch_ticket, resolve_ticket
from agent_precheck import precheck
from agent_update import update_dns
from agent_postcheck import postcheck


def run():
    steps = []

    # Fetch ticket
    ticket = fetch_ticket()
    domain = ticket["domain"]
    ip = ticket["ip"]

    steps.append(f"Ticket Number: {ticket['number']}")
    steps.append(f"Requested Domain: {domain}")
    steps.append(f"Requested IP: {ip}")

    # Pre-check
    exists, pre_msg = precheck(domain)
    steps.append(pre_msg)

    # Update if required
    if not exists:
        update_msg = update_dns(domain, ip)
        steps.append(update_msg)
    else:
        steps.append("No DNS update required")

    # Post-check
    verified, post_msg = postcheck(domain)
    steps.append(post_msg)

    status = "SUCCESS" if verified else "FAILED"

    # FIRST resolve ticket
    if verified:
        resolve_ticket(ticket["sys_id"], "DNS issue resolved successfully")

    # THEN build final summary
    summary = (
        "\n--- DNS TICKET RESOLUTION SUMMARY ---\n"
        + "\n".join(steps)
        + f"\n\nFinal Status: {status}"
    )

    # Show summary to user
    print(summary)

    # Update ticket with FULL summary (after resolution)
    if verified:
        resolve_ticket(ticket["sys_id"], summary)


if __name__ == "__main__":
    run()

import subprocess

DNS_SERVER = "10.0.0.6"


def precheck(domain):
    result = subprocess.run(
        ["dig", f"@{DNS_SERVER}", domain, "+short"],
        capture_output=True,
        text=True
    )

    output = result.stdout.strip()

    if output:
        return True, f"Pre-check: Domain already exists ({output})"
    return False, "Pre-check: Domain does not exist"

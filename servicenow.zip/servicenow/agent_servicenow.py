import requests
from requests.auth import HTTPBasicAuth

SERVICENOW_INSTANCE = "https://dev270315.service-now.com"
SERVICENOW_USER = "admin"
SERVICENOW_PASS = "Cj$yD6c-rC2P"
TABLE = "incident"


def fetch_ticket():
    url = f"{SERVICENOW_INSTANCE}/api/now/table/{TABLE}"
    params = {
        "sysparm_query": "state=1",  # New tickets
        "sysparm_limit": 1
    }

    response = requests.get(
        url,
        auth=HTTPBasicAuth(SERVICENOW_USER, SERVICENOW_PASS),
        headers={"Accept": "application/json"},
        params=params
    )
    response.raise_for_status()

    ticket = response.json()["result"][0]

    return {
        "sys_id": ticket["sys_id"],
        "number": ticket["number"],
        "domain": ticket["short_description"].strip(),
        "ip": ticket["description"].strip()
    }


def resolve_ticket(sys_id, summary):
    url = f"{SERVICENOW_INSTANCE}/api/now/table/{TABLE}/{sys_id}"

    payload = {
        "state": "6",  # Resolved
        "work_notes": summary,
        "close_notes": summary
    }

    response = requests.patch(
        url,
        auth=HTTPBasicAuth(SERVICENOW_USER, SERVICENOW_PASS),
        headers={"Content-Type": "application/json"},
        json=payload
    )
    response.raise_for_status()

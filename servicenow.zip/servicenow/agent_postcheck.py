import subprocess

DNS_SERVER = "10.0.0.6"


def postcheck(domain):
    result = subprocess.run(
        ["dig", f"@{DNS_SERVER}", domain, "+short"],
        capture_output=True,
        text=True
    )

    output = result.stdout.strip()

    if output:
        return True, f"Post-check: Domain resolved successfully ({output})"
    return False, "Post-check: Domain still not resolving"
